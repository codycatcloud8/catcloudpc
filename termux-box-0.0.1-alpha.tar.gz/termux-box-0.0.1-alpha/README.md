[Termux](https://f-droid.org/en/packages/com.termux)

[Termux-X11](https://github.com/termux/termux-x11/suites/13458717269/artifacts/738383219)

`curl -o install https://raw.githubusercontent.com/olegos2/a/main/install && chmod +x install && ./install`
